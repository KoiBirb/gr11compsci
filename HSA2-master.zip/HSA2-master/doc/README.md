## This folder contains the Javadoc files for the HSA2 java code. 

It will not be properly visible via GitHub. You need to download it and look at it using your browsers.
