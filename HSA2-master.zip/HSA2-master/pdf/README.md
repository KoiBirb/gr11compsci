## Useful PDF files

These files provide some basic information about the HSA console. The PDF files are not always correctly displayed when viewed via GitHub. You may need to download them.

Please also see the Javadoc files.

---
